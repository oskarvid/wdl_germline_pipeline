require 'open3'

# Class used to build and run an external process with log
class Command

  attr_accessor :line
  attr_reader   :captured_stdout, :captured_stderr, :pid, :exit_status

  def initialize(task_name: '', log: '')
    @log             = log
    @line            = []
    @task_name       = task_name
    @pid             = false # pid of the started process.
    @exit_status     = false
    @captured_stdout = ''
    @captured_stderr = ''
  end

  def run(compress_spaces: true, debug_mode: false)
    self.build!
    self.compress_spaces! if compress_spaces
    @log.execute(@task_name) { @line }
    if not debug_mode # debug mode
      Open3.popen3(@line) do |stdin, stdout, stderr, wait_thr|
        @pid             = wait_thr.pid
        @captured_stdout = stdout.read
        @captured_stderr = stderr.read
        @exit_status     = wait_thr.value
        unless exit_status.success?
          @log.warn(@task_name) { ": exit with error level" }
        end
      end
      @log.finish(@task_name) { @line }
    else
      wait_time = 0.2
      @log.debug(@task_name) { "Tool run in Debug mode : Skip the execution and wait #{wait_time} second(s) !!!" }
      sleep wait_time
    end
  end

  def test_binary
    out = `wich #{@line}` # test
    if out.include? 'not found'
      @log.warn(@task_name) { "#{@line} not found" }
    end
  end

  # command line Array to String
  def build!
    @line = @line.join ' ' if @line.class == Array
  end

  # remove multiple spaces
  def compress_spaces!
    @line.gsub!(/\s+/, ' ')
  end

end
